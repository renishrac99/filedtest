﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;

public partial class Default2 : System.Web.UI.Page
{
protected void Page_Load(object sender, EventArgs e)
{
}
}
